package oo.lista1.revisaoimpressao;

public class Println {
	public static void main(String[] args) {
		System.out.println("Println, Alô mundo !");
	}
}
