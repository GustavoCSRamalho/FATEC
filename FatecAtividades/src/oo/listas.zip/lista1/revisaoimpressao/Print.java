package oo.lista1.revisaoimpressao;

public class Print {
	public static void main (String[] args) {
		System.out.print("Print, Alô mundo !");
	}
}
