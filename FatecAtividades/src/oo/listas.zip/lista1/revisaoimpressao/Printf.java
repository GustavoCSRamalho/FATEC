package oo.lista1.revisaoimpressao;

public class Printf {
	public static void main(String[] args) {
		 System.out.printf("%s %s","Printf","Alô, mundo!");
	}
}
