package oo.lista1.revisaoestruturaselecao;

public class rfor {
	public static void main(String[] args) {
		System.out.println("**********");
		for(int quantidadeAsteristico = 8; quantidadeAsteristico > 0; quantidadeAsteristico--) {
			System.out.println("*        *");
		}
		System.out.println("**********");
	}
}
