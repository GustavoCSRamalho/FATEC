package oo.lista1.revisaoestruturaselecao;

public class rwhile {
	public static void main(String[] args) {
		int quantidadeAsteristico = 8;
		System.out.println("**********");
		while(quantidadeAsteristico > 0){
			System.out.println("*        *");
			quantidadeAsteristico--;
		}
		System.out.println("**********");

	}
}
