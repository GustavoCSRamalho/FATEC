package oo.lista4.modelos;

public interface Contato {
	public String dadosFormatados();
}
