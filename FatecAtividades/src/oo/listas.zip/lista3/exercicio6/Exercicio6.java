package oo.lista3.exercicio6;

public class Exercicio6 {
	public static void main(String[] args) {
		
	}
}
